def desvio_estandar():
    print("Resultado del Desvío Estándar")