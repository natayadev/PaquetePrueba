def sumar(numero1,numero2):
    print("Resultado de la suma: ", numero1+numero2)

def restar(numero1,numero2):
    print("Resultado de la resta: ", numero1-numero2)

def multiplicar(numero1,numero2):
    print("Resultado de la multiplicación: ", numero1*numero2)

def dividir(numero1,numero2):
    print("Resultado de la división: ", numero1/numero2)