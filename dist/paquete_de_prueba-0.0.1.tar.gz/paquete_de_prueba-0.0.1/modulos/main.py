from modulos_matematicos.calculos_aritmeticos import restar, sumar, dividir
from modulos_matematicos.modulos_estadisticos.calculos_desvios import desvio_estandar as ds


if __name__ == "__main__":
    restar(2,2)
    sumar(4,3)
    dividir(4,2)
    ds()
